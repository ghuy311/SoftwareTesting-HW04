import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Profile.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import axios from "/node_modules/.vite/deps/axios.js?v=4193fc5d";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Profile.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$();
export default function Profile() {
	_s();
	const { user, token } = useAuth();
	const [name, setName] = useState(user?.name || "");
	const [phone, setPhone] = useState(user?.phone || "");
	const [shippingAddress, setShippingAddress] = useState(user?.shipping_address || "");
	const [orders, setOrders] = useState([]);
	const fetchOrders = () => {
		if (!token) return;
		axios.get("http://localhost:3000/api/orders/my-orders", { headers: { Authorization: `Bearer ${token}` } }).then((res) => {
			const data = Array.isArray(res.data) ? res.data : res.data.orders || [];
			setOrders(data);
		}).catch((err) => {
			console.error("Lỗi lấy đơn hàng:", err);
			setOrders([]);
		});
	};
	useEffect(() => {
		if (user) {
			setName(user.name);
			setPhone(user.phone || "");
			setShippingAddress(user.shipping_address || "");
		}
		fetchOrders();
	}, [user, token]);
	const handleUpdate = async (e) => {
		e.preventDefault();
		if (!/^[1-9][0-9]{8,9}$/.test(phone)) {
			alert("Số điện thoại không hợp lệ. Vui lòng nhập đúng 9-10 chữ số.");
			return;
		}
		try {
			await axios.put("http://localhost:3000/api/users/me", {
				name,
				phone,
				shipping_address: shippingAddress
			}, { headers: { Authorization: `Bearer ${token}` } });
			alert("Cập nhật thành công!");
		} catch (err) {
			alert("Lỗi cập nhật");
		}
	};
	const cancelOrder = async (orderId) => {
		try {
			await axios.put(`http://localhost:3000/api/orders/${orderId}/cancel`, {}, { headers: { Authorization: `Bearer ${token}` } });
			alert("Hủy đơn thành công!");
			fetchOrders();
		} catch (err) {
			alert("Lỗi: " + (err.response?.data?.error || err.message));
		}
	};
	const statusStyle = (status) => {
		switch (status) {
			case "delivered": return "bg-green-100 text-green-800";
			case "shipping": return "bg-blue-100 text-blue-800";
			case "confirmed": return "bg-indigo-100 text-indigo-800";
			case "canceled": return "bg-red-100 text-red-800";
			default: return "bg-yellow-100 text-yellow-800";
		}
	};
	const statusLabel = (status) => {
		const labels = {
			pending: "Chờ xác nhận",
			confirmed: "Đã xác nhận",
			shipping: "Đang giao",
			delivered: "Đã giao",
			canceled: "Đã hủy"
		};
		return labels[status] || status.toUpperCase();
	};
	if (!user) return /* @__PURE__ */ _jsxDEV("div", {
		className: "text-center mt-10",
		children: "Vui lòng đăng nhập"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 21
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col md:flex-row gap-8",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "w-full md:w-1/3 bg-white p-6 border rounded shadow-sm",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold mb-4",
				children: "Hồ sơ của bạn"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleUpdate,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-gray-700 mb-1",
						children: "Email (Không đổi)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: user.email,
						disabled: true,
						className: "w-full border p-2 rounded bg-gray-100"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-gray-700 mb-1",
						children: "Họ Tên"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "w-full border p-2 rounded",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-gray-700 mb-1",
						children: "Số điện thoại"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						className: "w-full border p-2 rounded",
						placeholder: "VD: 0912345678"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-gray-700 mb-1",
						children: "Địa chỉ giao hàng"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						value: shippingAddress,
						onChange: (e) => setShippingAddress(e.target.value),
						className: "w-full border p-2 rounded h-24",
						placeholder: "Nhập địa chỉ của bạn"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "w-full bg-blue-600 text-white py-2 rounded",
						children: "Cập nhật"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full md:w-2/3 bg-white p-6 border rounded shadow-sm",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold mb-4",
				children: "Lịch sử đơn hàng"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 9
			}, this), orders.length === 0 ? /* @__PURE__ */ _jsxDEV("p", { children: "Bạn chưa có đơn hàng nào." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("table", {
				className: "w-full text-left",
				children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-b bg-gray-50",
					children: [
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-2",
							children: "Mã ĐH"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-2",
							children: "Ngày đặt"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-2",
							children: "Tổng tiền"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-2",
							children: "Trạng thái"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-2",
							children: "Thao tác"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: orders.map((o) => /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-b",
					children: [
						/* @__PURE__ */ _jsxDEV("td", {
							className: "p-2 font-mono",
							children: ["#", o.id]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "p-2",
							children: new Date(o.created_at).toLocaleDateString()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "p-2 text-red-600 font-bold",
							children: [Number(o.total_amount || 0).toLocaleString(), " ₫"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "p-2",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: `px-2 py-1 rounded text-sm ${statusStyle(o.status)}`,
								children: statusLabel(o.status)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "p-2",
							children: o.status !== "delivered" && o.status !== "canceled" && /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => cancelOrder(o.id),
								className: "bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-xs",
								children: "Hủy đơn"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 201,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 19
						}, this)
					]
				}, o.id, true, {
					fileName: _jsxFileName,
					lineNumber: 183,
					columnNumber: 17
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 166,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 5
	}, this);
}
_s(Profile, "1NWd4V6BkJm4Nq7/ANs0dEKKNyw=", false, function() {
	return [useAuth];
});
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Profile.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Profile.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Profile.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Profile.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLFVBQVU7O0NBQ2hDLE1BQU0sRUFBRSxNQUFNLFVBQVUsUUFBUTtDQUNoQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsTUFBTSxRQUFRLEVBQUU7Q0FDakQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLE1BQU0sU0FBUyxFQUFFO0NBQ3BELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQzVDLE1BQU0sb0JBQW9CLEVBQzVCO0NBQ0EsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLENBQUMsQ0FBQztDQUV2QyxNQUFNLG9CQUFvQjtFQUN4QixJQUFJLENBQUMsT0FBTztFQUVaLE1BQ0csSUFBSSw4Q0FBOEMsRUFDakQsU0FBUyxFQUFFLGVBQWUsVUFBVSxRQUFRLEVBQzlDLENBQUMsRUFDQSxNQUFNLFFBQVE7R0FDYixNQUFNLE9BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxJQUFJLElBQUksT0FBTyxJQUFJLEtBQUssVUFBVSxDQUFDO0dBQ3RFLFVBQVUsSUFBSTtFQUNoQixDQUFDLEVBQ0EsT0FBTyxRQUFRO0dBQ2QsUUFBUSxNQUFNLHFCQUFxQixHQUFHO0dBQ3RDLFVBQVUsQ0FBQyxDQUFDO0VBQ2QsQ0FBQztDQUNMO0NBRUEsZ0JBQWdCO0VBQ2QsSUFBSSxNQUFNO0dBQ1IsUUFBUSxLQUFLLElBQUk7R0FDakIsU0FBUyxLQUFLLFNBQVMsRUFBRTtHQUN6QixtQkFBbUIsS0FBSyxvQkFBb0IsRUFBRTtFQUNoRDtFQUNBLFlBQVk7Q0FDZCxHQUFHLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FFaEIsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUNoQyxFQUFFLGVBQWU7RUFFakIsSUFBSSxDQUFDLG9CQUFvQixLQUFLLEtBQUssR0FBRztHQUNwQyxNQUFNLDZEQUE2RDtHQUNuRTtFQUNGO0VBRUEsSUFBSTtHQUNGLE1BQU0sTUFBTSxJQUNWLHNDQUNBO0lBQ0U7SUFDQTtJQUNBLGtCQUFrQjtHQUNwQixHQUNBLEVBQ0UsU0FBUyxFQUFFLGVBQWUsVUFBVSxRQUFRLEVBQzlDLENBQ0Y7R0FDQSxNQUFNLHNCQUFzQjtFQUM5QixTQUFTLEtBQUs7R0FDWixNQUFNLGNBQWM7RUFDdEI7Q0FDRjtDQUVBLE1BQU0sY0FBYyxPQUFPLFlBQVk7RUFDckMsSUFBSTtHQUNGLE1BQU0sTUFBTSxJQUNWLG9DQUFvQyxRQUFRLFVBQzVDLENBQUMsR0FDRCxFQUNFLFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUSxFQUM5QyxDQUNGO0dBQ0EsTUFBTSxxQkFBcUI7R0FDM0IsWUFBWTtFQUNkLFNBQVMsS0FBSztHQUNaLE1BQU0sV0FBVyxJQUFJLFVBQVUsTUFBTSxTQUFTLElBQUksUUFBUTtFQUM1RDtDQUNGO0NBRUEsTUFBTSxlQUFlLFdBQVc7RUFDOUIsUUFBUSxRQUFSO0dBQ0UsS0FBSyxhQUNILE9BQU87R0FDVCxLQUFLLFlBQ0gsT0FBTztHQUNULEtBQUssYUFDSCxPQUFPO0dBQ1QsS0FBSyxZQUNILE9BQU87R0FDVCxTQUNFLE9BQU87RUFDWDtDQUNGO0NBRUEsTUFBTSxlQUFlLFdBQVc7RUFDOUIsTUFBTSxTQUFTO0dBQ2IsU0FBUztHQUNULFdBQVc7R0FDWCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7RUFDWjtFQUNBLE9BQU8sT0FBTyxXQUFXLE9BQU8sWUFBWTtDQUM5QztDQUVBLElBQUksQ0FBQyxNQUFNLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBb0I7Q0FBdUI7Ozs7O0NBRTVFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUEwQjtHQUFpQjs7OzthQUN6RCx3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFjLFdBQVU7Y0FBeEM7S0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQTJCO0tBRXJDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxPQUFPLEtBQUs7TUFDWjtNQUNBLFdBQVU7S0FDWDs7OzthQUNFOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBMkI7S0FBYTs7OztlQUN6RCx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU0sUUFBUSxFQUFFLE9BQU8sS0FBSztNQUN2QyxXQUFVO01BQ1Y7S0FDRDs7OzthQUNFOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBMkI7S0FBb0I7Ozs7ZUFDaEUsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxPQUFPO01BQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7TUFDeEMsV0FBVTtNQUNWLGFBQVk7S0FDYjs7OzthQUNFOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBMkI7S0FFckM7Ozs7ZUFDUCx3QkFBQyxZQUFEO01BQ0UsT0FBTztNQUNQLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7TUFDbEQsV0FBVTtNQUNWLGFBQVk7S0FDYjs7OzthQUNFOzs7OztLQUNMLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtnQkFDWDtLQUVPOzs7OztJQUNKOzs7OztXQUNIOzs7OztZQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUEwQjtHQUFvQjs7OzthQUMzRCxPQUFPLFdBQVcsSUFDakIsd0JBQUMsS0FBRCxZQUFHLDRCQUE0Qjs7OztjQUUvQix3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU07TUFBUzs7Ozs7TUFDN0Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU07TUFBWTs7Ozs7TUFDaEMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU07TUFBYTs7Ozs7TUFDakMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU07TUFBYzs7Ozs7TUFDbEMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU07TUFBWTs7Ozs7S0FDOUI7Ozs7O2FBQ0M7Ozs7Y0FDUCx3QkFBQyxTQUFELFlBQ0csT0FBTyxLQUFLLE1BQ1gsd0JBQUMsTUFBRDtLQUFlLFdBQVU7ZUFBekI7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUE4QixLQUFFLEVBQUUsRUFBTzs7Ozs7O01BQ3pDLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLElBQUksS0FBSyxFQUFFLFVBQVUsRUFBRSxtQkFBbUI7TUFDekM7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRyxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsRUFBRSxlQUFlLEdBQUUsSUFDNUM7Ozs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNaLHdCQUFDLFFBQUQ7UUFDRSxXQUFXLDZCQUE2QixZQUFZLEVBQUUsTUFBTTtrQkFFM0QsWUFBWSxFQUFFLE1BQU07T0FDakI7Ozs7O01BQ0o7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBRVgsRUFBRSxXQUFXLGVBQWUsRUFBRSxXQUFXLGNBQ3hDLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFlBQVksRUFBRSxFQUFFO1FBQy9CLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFFUjs7Ozs7S0FDRjtPQTFCSyxFQUFFOzs7O1dBMEJQLENBQ0wsRUFDSTs7OztZQUNGOzs7OztXQUVOOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9maWxlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZmlsZSgpIHtcclxuICBjb25zdCB7IHVzZXIsIHRva2VuIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUodXNlcj8ubmFtZSB8fCBcIlwiKTtcclxuICBjb25zdCBbcGhvbmUsIHNldFBob25lXSA9IHVzZVN0YXRlKHVzZXI/LnBob25lIHx8IFwiXCIpO1xyXG4gIGNvbnN0IFtzaGlwcGluZ0FkZHJlc3MsIHNldFNoaXBwaW5nQWRkcmVzc10gPSB1c2VTdGF0ZShcclxuICAgIHVzZXI/LnNoaXBwaW5nX2FkZHJlc3MgfHwgXCJcIixcclxuICApO1xyXG4gIGNvbnN0IFtvcmRlcnMsIHNldE9yZGVyc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoT3JkZXJzID0gKCkgPT4ge1xyXG4gICAgaWYgKCF0b2tlbikgcmV0dXJuO1xyXG5cclxuICAgIGF4aW9zXHJcbiAgICAgIC5nZXQoXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL29yZGVycy9teS1vcmRlcnNcIiwge1xyXG4gICAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSxcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBBcnJheS5pc0FycmF5KHJlcy5kYXRhKSA/IHJlcy5kYXRhIDogcmVzLmRhdGEub3JkZXJzIHx8IFtdO1xyXG4gICAgICAgIHNldE9yZGVycyhkYXRhKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiTOG7l2kgbOG6pXkgxJHGoW4gaMOgbmc6XCIsIGVycik7XHJcbiAgICAgICAgc2V0T3JkZXJzKFtdKTtcclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIHNldE5hbWUodXNlci5uYW1lKTtcclxuICAgICAgc2V0UGhvbmUodXNlci5waG9uZSB8fCBcIlwiKTtcclxuICAgICAgc2V0U2hpcHBpbmdBZGRyZXNzKHVzZXIuc2hpcHBpbmdfYWRkcmVzcyB8fCBcIlwiKTtcclxuICAgIH1cclxuICAgIGZldGNoT3JkZXJzKCk7XHJcbiAgfSwgW3VzZXIsIHRva2VuXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKCEvXlsxLTldWzAtOV17OCw5fSQvLnRlc3QocGhvbmUpKSB7XHJcbiAgICAgIGFsZXJ0KFwiU+G7kSDEkWnhu4duIHRob+G6oWkga2jDtG5nIGjhu6NwIGzhu4cuIFZ1aSBsw7JuZyBuaOG6rXAgxJHDum5nIDktMTAgY2jhu68gc+G7kS5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBheGlvcy5wdXQoXHJcbiAgICAgICAgXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3VzZXJzL21lXCIsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZSxcclxuICAgICAgICAgIHBob25lLFxyXG4gICAgICAgICAgc2hpcHBpbmdfYWRkcmVzczogc2hpcHBpbmdBZGRyZXNzLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICk7XHJcbiAgICAgIGFsZXJ0KFwiQ+G6rXAgbmjhuq10IHRow6BuaCBjw7RuZyFcIik7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgYWxlcnQoXCJM4buXaSBj4bqtcCBuaOG6rXRcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FuY2VsT3JkZXIgPSBhc3luYyAob3JkZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXhpb3MucHV0KFxyXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL29yZGVycy8ke29yZGVySWR9L2NhbmNlbGAsXHJcbiAgICAgICAge30sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICk7XHJcbiAgICAgIGFsZXJ0KFwiSOG7p3kgxJHGoW4gdGjDoG5oIGPDtG5nIVwiKTtcclxuICAgICAgZmV0Y2hPcmRlcnMoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydChcIkzhu5dpOiBcIiArIChlcnIucmVzcG9uc2U/LmRhdGE/LmVycm9yIHx8IGVyci5tZXNzYWdlKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc3RhdHVzU3R5bGUgPSAoc3RhdHVzKSA9PiB7XHJcbiAgICBzd2l0Y2ggKHN0YXR1cykge1xyXG4gICAgICBjYXNlIFwiZGVsaXZlcmVkXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwXCI7XHJcbiAgICAgIGNhc2UgXCJzaGlwcGluZ1wiOlxyXG4gICAgICAgIHJldHVybiBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDBcIjtcclxuICAgICAgY2FzZSBcImNvbmZpcm1lZFwiOlxyXG4gICAgICAgIHJldHVybiBcImJnLWluZGlnby0xMDAgdGV4dC1pbmRpZ28tODAwXCI7XHJcbiAgICAgIGNhc2UgXCJjYW5jZWxlZFwiOlxyXG4gICAgICAgIHJldHVybiBcImJnLXJlZC0xMDAgdGV4dC1yZWQtODAwXCI7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuIFwiYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDBcIjtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzdGF0dXNMYWJlbCA9IChzdGF0dXMpID0+IHtcclxuICAgIGNvbnN0IGxhYmVscyA9IHtcclxuICAgICAgcGVuZGluZzogXCJDaOG7nSB4w6FjIG5o4bqtblwiLFxyXG4gICAgICBjb25maXJtZWQ6IFwixJDDoyB4w6FjIG5o4bqtblwiLFxyXG4gICAgICBzaGlwcGluZzogXCLEkGFuZyBnaWFvXCIsXHJcbiAgICAgIGRlbGl2ZXJlZDogXCLEkMOjIGdpYW9cIixcclxuICAgICAgY2FuY2VsZWQ6IFwixJDDoyBo4buneVwiLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBsYWJlbHNbc3RhdHVzXSB8fCBzdGF0dXMudG9VcHBlckNhc2UoKTtcclxuICB9O1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG10LTEwXCI+VnVpIGzDsm5nIMSRxINuZyBuaOG6rXA8L2Rpdj47XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgZ2FwLThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzMgYmctd2hpdGUgcC02IGJvcmRlciByb3VuZGVkIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItNFwiPkjhu5Mgc8ahIGPhu6dhIGLhuqFuPC9oMj5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICBFbWFpbCAoS2jDtG5nIMSR4buVaSlcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXt1c2VyLmVtYWlsfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBwLTIgcm91bmRlZCBiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LWdyYXktNzAwIG1iLTFcIj5I4buNIFTDqm48L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e25hbWV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1ncmF5LTcwMCBtYi0xXCI+U+G7kSDEkWnhu4duIHRob+G6oWk8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Bob25lfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGhvbmUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVkQ6IDA5MTIzNDU2NzhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgxJDhu4thIGNo4buJIGdpYW8gaMOgbmdcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NoaXBwaW5nQWRkcmVzc31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNoaXBwaW5nQWRkcmVzcyhlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBwLTIgcm91bmRlZCBoLTI0XCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5o4bqtcCDEkeG7i2EgY2jhu4kgY+G7p2EgYuG6oW5cIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBweS0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBD4bqtcCBuaOG6rXRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTIvMyBiZy13aGl0ZSBwLTYgYm9yZGVyIHJvdW5kZWQgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtYi00XCI+TOG7i2NoIHPhu60gxJHGoW4gaMOgbmc8L2gyPlxyXG4gICAgICAgIHtvcmRlcnMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPHA+QuG6oW4gY2jGsGEgY8OzIMSRxqFuIGjDoG5nIG7DoG8uPC9wPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTJcIj5Nw6MgxJBIPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTJcIj5OZ8OgeSDEkeG6t3Q8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlThu5VuZyB0aeG7gW48L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlRy4bqhbmcgdGjDoWk8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlRoYW8gdMOhYzwvdGg+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgIHtvcmRlcnMubWFwKChvKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtvLmlkfSBjbGFzc05hbWU9XCJib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGZvbnQtbW9ub1wiPiN7by5pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKG8uY3JlYXRlZF9hdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgdGV4dC1yZWQtNjAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtOdW1iZXIoby50b3RhbF9hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoKX0g4oKrXHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0xIHJvdW5kZWQgdGV4dC1zbSAke3N0YXR1c1N0eWxlKG8uc3RhdHVzKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXNMYWJlbChvLnN0YXR1cyl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE7DunQgaOG7p3kgaGnhu4NuIHRo4buLIGtoaSBjaMawYSBnaWFvIHhvbmcgdsOgIGNoxrBhIGjhu6d5IChr4buDIGPhuqMga2hpIMSRYW5nIGdpYW8pICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHtvLnN0YXR1cyAhPT0gXCJkZWxpdmVyZWRcIiAmJiBvLnN0YXR1cyAhPT0gXCJjYW5jZWxlZFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2FuY2VsT3JkZXIoby5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC01MDAgaG92ZXI6YmctcmVkLTYwMCB0ZXh0LXdoaXRlIHB4LTMgcHktMSByb3VuZGVkIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBI4buneSDEkcahblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=