import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ProductDetail.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=4193fc5d";
import axios from "/node_modules/.vite/deps/axios.js?v=4193fc5d";
import { useCart } from "/src/context/CartContext.jsx";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ProductDetail.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$();
export default function ProductDetail() {
	_s();
	const { id } = useParams();
	const [product, setProduct] = useState(null);
	const [quantity, setQuantity] = useState(1);
	const { addToCart } = useCart();
	const [added, setAdded] = useState(false);
	const [clickCount, setClickCount] = useState(0);
	useEffect(() => {
		axios.get(`http://localhost:3000/api/products/${id}`).then((res) => setProduct(res.data)).catch((err) => console.error(err));
	}, [id]);
	const handleAddToCart = () => {
		if (clickCount === 0) {
			setClickCount(1);
			return;
		}
		addToCart(product, parseInt(quantity));
		setAdded(true);
		setClickCount(0);
		setTimeout(() => setAdded(false), 2e3);
	};
	if (!product) return /* @__PURE__ */ _jsxDEV("div", { children: "Đang tải..." }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 24
	}, this);
	if (Object.keys(product).length === 0) return /* @__PURE__ */ _jsxDEV("div", { children: "Sản phẩm không tồn tại (Lỗi trắng trang do data rỗng)" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 12
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white p-6 border rounded shadow-sm flex flex-col md:flex-row gap-8",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "w-full md:w-1/2",
			children: /* @__PURE__ */ _jsxDEV("img", {
				src: product.imageUrl,
				alt: product.name,
				className: "w-full h-auto rounded"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full md:w-1/2 flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-3xl font-bold mb-4",
					children: product.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-2xl text-red-600 font-bold mb-4",
					children: [Number(product.price).toLocaleString(), " ₫"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-gray-700 mb-6 flex-grow",
					children: product.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4 mb-4",
					children: [/* @__PURE__ */ _jsxDEV("label", { children: "Số lượng:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "number",
						value: quantity,
						onChange: (e) => setQuantity(e.target.value),
						className: "border p-2 w-20 rounded"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: handleAddToCart,
					className: "bg-green-600 text-white py-3 px-6 rounded hover:bg-green-700 self-start bug-mobile-hidden",
					children: added ? "Đã thêm" : "Thêm vào giỏ hàng"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_s(ProductDetail, "LG6BHuAfiRASLeYYrp4JiGEB+Lk=", false, function() {
	return [useParams, useCart];
});
_c = ProductDetail;
var _c;
$RefreshReg$(_c, "ProductDetail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ProductDetail.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ProductDetail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ProductDetail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ProductDetail.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsaUJBQWlCO0FBQzFCLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLGdCQUFnQjs7Q0FDdEMsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUMxQyxNQUFNLEVBQUUsY0FBYyxRQUFRO0NBQzlCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxLQUFLO0NBQ3hDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLENBQUM7Q0FFOUMsZ0JBQWdCO0VBQ2QsTUFDRyxJQUFJLHNDQUFzQyxJQUFJLEVBQzlDLE1BQU0sUUFBUSxXQUFXLElBQUksSUFBSSxDQUFDLEVBQ2xDLE9BQU8sUUFBUSxRQUFRLE1BQU0sR0FBRyxDQUFDO0NBQ3RDLEdBQUcsQ0FBQyxFQUFFLENBQUM7Q0FFUCxNQUFNLHdCQUF3QjtFQUM1QixJQUFJLGVBQWUsR0FBRztHQUNwQixjQUFjLENBQUM7R0FDZjtFQUNGO0VBRUEsVUFBVSxTQUFTLFNBQVMsUUFBUSxDQUFDO0VBQ3JDLFNBQVMsSUFBSTtFQUNiLGNBQWMsQ0FBQztFQUNmLGlCQUFpQixTQUFTLEtBQUssR0FBRyxHQUFJO0NBQ3hDO0NBRUEsSUFBSSxDQUFDLFNBQVMsT0FBTyx3QkFBQyxPQUFELFlBQUssY0FBZ0I7Ozs7O0NBQzFDLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRSxXQUFXLEdBQ2xDLE9BQU8sd0JBQUMsT0FBRCxZQUFLLHdEQUEwRDs7Ozs7Q0FFeEUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQ0UsS0FBSyxRQUFRO0lBQ2IsS0FBSyxRQUFRO0lBQ2IsV0FBVTtHQUNYOzs7OztFQUNFOzs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQTJCLFFBQVE7SUFBUzs7Ozs7SUFFMUQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYixDQUNHLE9BQU8sUUFBUSxLQUFLLEVBQUUsZUFBZSxHQUFFLElBQ3ZDOzs7Ozs7SUFDSCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFnQyxRQUFRO0lBQWU7Ozs7O0lBRXBFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxTQUFELFlBQU8sWUFBZ0I7Ozs7ZUFDdkIsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxPQUFPO01BQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7TUFDM0MsV0FBVTtLQUNYOzs7O2FBQ0U7Ozs7OztJQUVMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUVULFFBQVEsWUFBWTtJQUNmOzs7OztHQUNMOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0RGV0YWlsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tIFwiLi4vY29udGV4dC9DYXJ0Q29udGV4dFwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZHVjdERldGFpbCgpIHtcclxuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBbcHJvZHVjdCwgc2V0UHJvZHVjdF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcXVhbnRpdHksIHNldFF1YW50aXR5XSA9IHVzZVN0YXRlKDEpO1xyXG4gIGNvbnN0IHsgYWRkVG9DYXJ0IH0gPSB1c2VDYXJ0KCk7XHJcbiAgY29uc3QgW2FkZGVkLCBzZXRBZGRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NsaWNrQ291bnQsIHNldENsaWNrQ291bnRdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBheGlvc1xyXG4gICAgICAuZ2V0KGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Byb2R1Y3RzLyR7aWR9YClcclxuICAgICAgLnRoZW4oKHJlcykgPT4gc2V0UHJvZHVjdChyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmVycm9yKGVycikpO1xyXG4gIH0sIFtpZF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRUb0NhcnQgPSAoKSA9PiB7XHJcbiAgICBpZiAoY2xpY2tDb3VudCA9PT0gMCkge1xyXG4gICAgICBzZXRDbGlja0NvdW50KDEpO1xyXG4gICAgICByZXR1cm47IC8vIEtow7RuZyBsw6BtIGfDrCBj4bqjIOG7nyBs4bqnbiDEkeG6p3UgdGnDqm5cclxuICAgIH1cclxuXHJcbiAgICBhZGRUb0NhcnQocHJvZHVjdCwgcGFyc2VJbnQocXVhbnRpdHkpKTtcclxuICAgIHNldEFkZGVkKHRydWUpO1xyXG4gICAgc2V0Q2xpY2tDb3VudCgwKTsgLy8gUmVzZXQgbOG6oWlcclxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWRkZWQoZmFsc2UpLCAyMDAwKTtcclxuICB9O1xyXG5cclxuICBpZiAoIXByb2R1Y3QpIHJldHVybiA8ZGl2PsSQYW5nIHThuqNpLi4uPC9kaXY+O1xyXG4gIGlmIChPYmplY3Qua2V5cyhwcm9kdWN0KS5sZW5ndGggPT09IDApXHJcbiAgICByZXR1cm4gPGRpdj5T4bqjbiBwaOG6qW0ga2jDtG5nIHThu5NuIHThuqFpIChM4buXaSB0cuG6r25nIHRyYW5nIGRvIGRhdGEgcuG7l25nKTwvZGl2PjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IGJvcmRlciByb3VuZGVkIHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGdhcC04XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS8yXCI+XHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgc3JjPXtwcm9kdWN0LmltYWdlVXJsfVxyXG4gICAgICAgICAgYWx0PXtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1hdXRvIHJvdW5kZWRcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvMiBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCBtYi00XCI+e3Byb2R1Y3QubmFtZX08L2gxPlxyXG4gICAgICAgIHsvKiBM4buXaSBnacOhIHRy4buLIE5hTiBjw7MgdGjhu4MgeHXhuqV0IGhp4buHbiBu4bq/dSBwcmljZSBi4buLIGzhu5dpIMSR4buLbmggZOG6oW5nIHThu6sgYmFja2VuZCAqL31cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXJlZC02MDAgZm9udC1ib2xkIG1iLTRcIj5cclxuICAgICAgICAgIHtOdW1iZXIocHJvZHVjdC5wcmljZSkudG9Mb2NhbGVTdHJpbmcoKX0g4oKrXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgbWItNiBmbGV4LWdyb3dcIj57cHJvZHVjdC5kZXNjcmlwdGlvbn08L3A+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgPGxhYmVsPlPhu5EgbMaw4bujbmc6PC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgdmFsdWU9e3F1YW50aXR5fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFF1YW50aXR5KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiB3LTIwIHJvdW5kZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkVG9DYXJ0fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHktMyBweC02IHJvdW5kZWQgaG92ZXI6YmctZ3JlZW4tNzAwIHNlbGYtc3RhcnQgYnVnLW1vYmlsZS1oaWRkZW5cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHthZGRlZCA/IFwixJDDoyB0aMOqbVwiIDogXCJUaMOqbSB2w6BvIGdp4buPIGjDoG5nXCJ9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=