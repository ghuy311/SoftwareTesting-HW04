import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/CartContext.jsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useState = __vite__cjsImport0_react["useState"]; const useContext = __vite__cjsImport0_react["useContext"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/CartContext.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const CartContext = createContext(null);
_c = CartContext;
export const CartProvider = ({ children }) => {
	_s();
	const [cart, setCart] = useState([]);
	const addToCart = (product, quantity) => {
		setCart([...cart, {
			...product,
			quantity
		}]);
	};
	const removeFromCart = (index) => {
		const newCart = [...cart];
		newCart.splice(index, 1);
		setCart(newCart);
	};
	const clearCart = () => {
		setCart([]);
	};
	const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);
	return /* @__PURE__ */ _jsxDEV(CartContext.Provider, {
		value: {
			cart,
			addToCart,
			removeFromCart,
			clearCart,
			cartTotal
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
};
_s(CartProvider, "ZqFaEIYkzI5UoYUmTgmqHbYYm/0=");
_c2 = CartProvider;
export const useCart = () => {
	_s2();
	return useContext(CartContext);
};
_s2(useCart, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c, _c2;
$RefreshReg$(_c, "CartContext");
$RefreshReg$(_c2, "CartProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/CartContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/CartContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/CartContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/CartContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsVUFBVSxrQkFBa0I7Ozs7QUFFM0QsTUFBTSxjQUFjLGNBQWMsSUFBSTs7QUFFdEMsT0FBTyxNQUFNLGdCQUFnQixFQUFFLGVBQWU7O0NBQzVDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDLENBQUM7Q0FFbkMsTUFBTSxhQUFhLFNBQVMsYUFBYTtFQUN2QyxRQUFRLENBQUMsR0FBRyxNQUFNO0dBQUUsR0FBRztHQUFTO0VBQVMsQ0FBQyxDQUFDO0NBQzdDO0NBRUEsTUFBTSxrQkFBa0IsVUFBVTtFQUNoQyxNQUFNLFVBQVUsQ0FBQyxHQUFHLElBQUk7RUFDeEIsUUFBUSxPQUFPLE9BQU8sQ0FBQztFQUN2QixRQUFRLE9BQU87Q0FDakI7Q0FFQSxNQUFNLGtCQUFrQjtFQUN0QixRQUFRLENBQUMsQ0FBQztDQUNaO0NBRUEsTUFBTSxZQUFZLEtBQUssUUFDcEIsT0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLEtBQUssVUFDM0MsQ0FDRjtDQUVBLE9BQ0Usd0JBQUMsWUFBWSxVQUFiO0VBQ0UsT0FBTztHQUFFO0dBQU07R0FBVztHQUFnQjtHQUFXO0VBQVU7RUFFOUQ7Q0FDbUI7Ozs7O0FBRTFCOzs7QUFFQSxPQUFPLE1BQU0sZ0JBQWdCOzttQkFBVyxXQUFXIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcnRDb250ZXh0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmNvbnN0IENhcnRDb250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKTtcclxuXHJcbmV4cG9ydCBjb25zdCBDYXJ0UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgY29uc3QgW2NhcnQsIHNldENhcnRdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBhZGRUb0NhcnQgPSAocHJvZHVjdCwgcXVhbnRpdHkpID0+IHtcclxuICAgIHNldENhcnQoWy4uLmNhcnQsIHsgLi4ucHJvZHVjdCwgcXVhbnRpdHkgfV0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZUZyb21DYXJ0ID0gKGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCBuZXdDYXJ0ID0gWy4uLmNhcnRdO1xyXG4gICAgbmV3Q2FydC5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgc2V0Q2FydChuZXdDYXJ0KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjbGVhckNhcnQgPSAoKSA9PiB7XHJcbiAgICBzZXRDYXJ0KFtdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjYXJ0VG90YWwgPSBjYXJ0LnJlZHVjZShcclxuICAgICh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnByaWNlICogaXRlbS5xdWFudGl0eSxcclxuICAgIDAsXHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJ0Q29udGV4dC5Qcm92aWRlclxyXG4gICAgICB2YWx1ZT17eyBjYXJ0LCBhZGRUb0NhcnQsIHJlbW92ZUZyb21DYXJ0LCBjbGVhckNhcnQsIGNhcnRUb3RhbCB9fVxyXG4gICAgPlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L0NhcnRDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgdXNlQ2FydCA9ICgpID0+IHVzZUNvbnRleHQoQ2FydENvbnRleHQpO1xyXG4iXX0=