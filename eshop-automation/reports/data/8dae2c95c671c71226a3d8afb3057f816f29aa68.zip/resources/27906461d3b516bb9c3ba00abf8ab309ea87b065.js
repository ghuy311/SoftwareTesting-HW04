import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Cart.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4193fc5d";
import { useCart } from "/src/context/CartContext.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Cart.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$();
export default function Cart() {
	_s();
	const { cart, removeFromCart, cartTotal } = useCart();
	const { user } = useAuth();
	const navigate = useNavigate();
	const handleCheckout = () => {
		if (!user) {
			alert("Bạn cần đăng nhập để thanh toán!");
			navigate("/login");
			return;
		}
		navigate("/checkout");
	};
	if (cart.length === 0) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center mt-10",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl mb-4",
				children: "Giỏ hàng của bạn đang trống"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				className: "text-blue-600 hover:underline",
				children: "Tiếp tục mua sắm"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white p-6 border rounded shadow-sm",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold mb-6",
				children: "Giỏ Hàng"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("table", {
				className: "w-full text-left mb-6",
				children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-b",
					children: [
						/* @__PURE__ */ _jsxDEV("th", {
							className: "py-2",
							children: "Sản phẩm"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "py-2",
							children: "Giá"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "py-2",
							children: "Số lượng"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "py-2",
							children: "Thành tiền"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "py-2",
							children: "Thao tác"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: cart.map((item, index) => /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-b",
					children: [
						/* @__PURE__ */ _jsxDEV("td", {
							className: "py-4",
							children: item.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: [Number(item.price).toLocaleString(), " ₫"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: item.quantity }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: [(Number(item.price) * item.quantity).toLocaleString(), " ₫"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => removeFromCart(index),
							className: "text-red-500 hover:text-red-700",
							children: "Xóa"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this)
					]
				}, index, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 13
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-between items-center",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "text-xl font-bold",
					children: ["Tổng tạm tính: ", /* @__PURE__ */ _jsxDEV("span", {
						className: "text-red-600",
						children: [cartTotal.toLocaleString(), " ₫"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 26
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "border px-4 py-2 rounded text-gray-600 hover:bg-gray-50",
						children: "← Mua tiếp"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleCheckout,
						className: "bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600",
						children: "Tiến hành thanh toán"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_s(Cart, "Zovpr0QNGC+6dnNmz7ZiMOK4eok=", false, function() {
	return [
		useCart,
		useAuth,
		useNavigate
	];
});
_c = Cart;
var _c;
$RefreshReg$(_c, "Cart");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Cart.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Cart.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Cart.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Cart.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsTUFBTSxtQkFBbUI7QUFDbEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsT0FBTzs7Q0FDN0IsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLGNBQWMsUUFBUTtDQUNwRCxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sdUJBQXVCO0VBQzNCLElBQUksQ0FBQyxNQUFNO0dBQ1QsTUFBTSxrQ0FBa0M7R0FDeEMsU0FBUyxRQUFRO0dBQ2pCO0VBQ0Y7RUFDQSxTQUFTLFdBQVc7Q0FDdEI7Q0FFQSxJQUFJLEtBQUssV0FBVyxHQUFHO0VBQ3JCLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWdCO0dBQStCOzs7O2FBQzdELHdCQUFDLE1BQUQ7SUFBTSxJQUFHO0lBQUksV0FBVTtjQUFnQztHQUFzQjs7OztXQUMxRTs7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUEwQjtHQUFZOzs7OztHQUNwRCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU87TUFBWTs7Ozs7TUFDakMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU87TUFBTzs7Ozs7TUFDNUIsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU87TUFBWTs7Ozs7TUFDakMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU87TUFBYzs7Ozs7TUFDbkMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQU87TUFBWTs7Ozs7S0FDL0I7Ozs7O2FBQ0M7Ozs7Y0FDUCx3QkFBQyxTQUFELFlBQ0csS0FBSyxLQUFLLE1BQU0sVUFDZix3QkFBQyxNQUFEO0tBQWdCLFdBQVU7ZUFBMUI7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBUSxLQUFLO01BQVM7Ozs7O01BQ3BDLHdCQUFDLE1BQUQsYUFBSyxPQUFPLEtBQUssS0FBSyxFQUFFLGVBQWUsR0FBRSxJQUFNOzs7OztNQUMvQyx3QkFBQyxNQUFELFlBQUssS0FBSyxTQUFhOzs7OztNQUN2Qix3QkFBQyxNQUFELGNBQU0sT0FBTyxLQUFLLEtBQUssSUFBSSxLQUFLLFVBQVUsZUFBZSxHQUFFLElBQU07Ozs7O01BQ2pFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxlQUFlLEtBQUs7T0FDbkMsV0FBVTtpQkFDWDtNQUVPOzs7O2VBQ047Ozs7O0tBQ0Y7T0FiSzs7OztXQWFMLENBQ0wsRUFDSTs7OztZQUNGOzs7Ozs7R0FDUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFtQyxtQkFDbEIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQWdDLFVBQVUsZUFBZSxHQUFFLElBQVE7Ozs7O2FBQy9FOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQU0sSUFBRztNQUFJLFdBQVU7Z0JBQTBEO0tBRTNFOzs7O2VBQ04sd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcnQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICcuLi9jb250ZXh0L0NhcnRDb250ZXh0JztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2FydCgpIHtcclxuICBjb25zdCB7IGNhcnQsIHJlbW92ZUZyb21DYXJ0LCBjYXJ0VG90YWwgfSA9IHVzZUNhcnQoKTtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoZWNrb3V0ID0gKCkgPT4ge1xyXG4gICAgaWYgKCF1c2VyKSB7XHJcbiAgICAgIGFsZXJ0KFwiQuG6oW4gY+G6p24gxJHEg25nIG5o4bqtcCDEkeG7gyB0aGFuaCB0b8OhbiFcIik7XHJcbiAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgbmF2aWdhdGUoJy9jaGVja291dCcpO1xyXG4gIH07XHJcblxyXG4gIGlmIChjYXJ0Lmxlbmd0aCA9PT0gMCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC0xMFwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBtYi00XCI+R2nhu48gaMOgbmcgY+G7p2EgYuG6oW4gxJFhbmcgdHLhu5FuZzwvaDI+XHJcbiAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBob3Zlcjp1bmRlcmxpbmVcIj5UaeG6v3AgdOG7pWMgbXVhIHPhuq9tPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgYm9yZGVyIHJvdW5kZWQgc2hhZG93LXNtXCI+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItNlwiPkdp4buPIEjDoG5nPC9oMj5cclxuICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgbWItNlwiPlxyXG4gICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYlwiPlxyXG4gICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMlwiPlPhuqNuIHBo4bqpbTwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yXCI+R2nDoTwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yXCI+U+G7kSBsxrDhu6NuZzwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yXCI+VGjDoG5oIHRp4buBbjwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yXCI+VGhhbyB0w6FjPC90aD5cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICB7Y2FydC5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+e2l0ZW0ubmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZD57TnVtYmVyKGl0ZW0ucHJpY2UpLnRvTG9jYWxlU3RyaW5nKCl9IOKCqzwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPntpdGVtLnF1YW50aXR5fTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPnsoTnVtYmVyKGl0ZW0ucHJpY2UpICogaXRlbS5xdWFudGl0eSkudG9Mb2NhbGVTdHJpbmcoKX0g4oKrPC90ZD5cclxuICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZUZyb21DYXJ0KGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFjDs2FcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L3Rib2R5PlxyXG4gICAgICA8L3RhYmxlPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGRcIj5cclxuICAgICAgICAgIFThu5VuZyB04bqhbSB0w61uaDogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCI+e2NhcnRUb3RhbC50b0xvY2FsZVN0cmluZygpfSDigqs8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJib3JkZXIgcHgtNCBweS0yIHJvdW5kZWQgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgIOKGkCBNdWEgdGnhur9wXHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNoZWNrb3V0fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSBweC02IHB5LTIgcm91bmRlZCBob3ZlcjpiZy1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBUaeG6v24gaMOgbmggdGhhbmggdG/DoW5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19