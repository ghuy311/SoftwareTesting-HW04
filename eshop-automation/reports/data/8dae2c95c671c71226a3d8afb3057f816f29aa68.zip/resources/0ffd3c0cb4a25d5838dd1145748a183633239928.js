import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Home.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=4193fc5d";
import axios from "/node_modules/.vite/deps/axios.js?v=4193fc5d";
import { useCart } from "/src/context/CartContext.jsx";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Home.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$();
export default function Home() {
	_s();
	const [products, setProducts] = useState([]);
	const [search, setSearch] = useState("");
	const [errorHtml, setErrorHtml] = useState("");
	const { addToCart } = useCart();
	const fetchProducts = async (query = "") => {
		try {
			setErrorHtml("");
			const res = await axios.get(`http://localhost:3000/api/products?search=${query}`);
			if (typeof res.data === "string" && res.data.includes("<h1>")) {
				setErrorHtml(res.data);
				setProducts([]);
			} else {
				setProducts(res.data);
			}
		} catch (err) {
			if (err.response && typeof err.response.data === "string") {
				setErrorHtml(err.response.data);
			}
		}
	};
	useEffect(() => {
		fetchProducts();
	}, []);
	const handleSearch = (e) => {
		e.preventDefault();
		fetchProducts(search);
	};
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex justify-between items-center mb-6",
			children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-3xl font-bold",
				children: "Danh sách sản phẩm"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSearch,
				className: "flex gap-2",
				children: [/* @__PURE__ */ _jsxDEV("input", {
					type: "text",
					placeholder: "Tìm kiếm...",
					value: search,
					onChange: (e) => setSearch(e.target.value),
					className: "border p-2 rounded"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					className: "bg-blue-600 text-white px-4 py-2 rounded",
					children: "Tìm"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this),
		search && !errorHtml && /* @__PURE__ */ _jsxDEV("div", {
			className: "mb-4 text-gray-600",
			children: [
				"Kết quả tìm kiếm cho:",
				" ",
				/* @__PURE__ */ _jsxDEV("span", { dangerouslySetInnerHTML: { __html: search } }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 9
		}, this),
		errorHtml ? /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-red-100 p-4 rounded overflow-auto",
			dangerouslySetInnerHTML: { __html: errorHtml }
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6",
			children: products.map((p) => /* @__PURE__ */ _jsxDEV("div", {
				className: "border rounded shadow-sm p-4 flex flex-col bg-white",
				children: [
					/* @__PURE__ */ _jsxDEV("img", {
						src: p.imageUrl,
						alt: "",
						className: "w-full h-48 object-cover mb-4 rounded"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-semibold mb-2 truncate",
						children: p.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-red-500 font-bold mb-2",
						children: [Number(p.price).toLocaleString(), " VND"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-auto flex gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: `/product/${p.id}`,
							className: "flex-1 text-center bg-gray-200 py-2 rounded hover:bg-gray-300 text-sm",
							children: "Xem chi tiết"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => addToCart({
								...p,
								quantity: 1
							}, 1),
							className: "flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700 text-sm",
							children: "Thêm vào giỏ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this)
				]
			}, p.id, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 9
		}, this),
		products.length > 0 && /* @__PURE__ */ _jsxDEV("h1", {
			className: "text-center text-gray-400 mt-8 text-sm",
			children: [
				"Hiển thị ",
				products.length,
				" sản phẩm"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_s(Home, "2uxyS6HfaZOK9Lh0Kq1X5Oqwukc=", false, function() {
	return [useCart];
});
_c = Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Home.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Home.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/Home.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsWUFBWTtBQUNyQixPQUFPLFdBQVc7QUFDbEIsU0FBUyxlQUFlOzs7O0FBRXhCLGVBQWUsU0FBUyxPQUFPOztDQUM3QixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQyxDQUFDO0NBQzNDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxFQUFFLGNBQWMsUUFBUTtDQUU5QixNQUFNLGdCQUFnQixPQUFPLFFBQVEsT0FBTztFQUMxQyxJQUFJO0dBQ0YsYUFBYSxFQUFFO0dBQ2YsTUFBTSxNQUFNLE1BQU0sTUFBTSxJQUN0Qiw2Q0FBNkMsT0FDL0M7R0FDQSxJQUFJLE9BQU8sSUFBSSxTQUFTLFlBQVksSUFBSSxLQUFLLFNBQVMsTUFBTSxHQUFHO0lBQzdELGFBQWEsSUFBSSxJQUFJO0lBQ3JCLFlBQVksQ0FBQyxDQUFDO0dBQ2hCLE9BQU87SUFDTCxZQUFZLElBQUksSUFBSTtHQUN0QjtFQUNGLFNBQVMsS0FBSztHQUNaLElBQUksSUFBSSxZQUFZLE9BQU8sSUFBSSxTQUFTLFNBQVMsVUFBVTtJQUN6RCxhQUFhLElBQUksU0FBUyxJQUFJO0dBQ2hDO0VBQ0Y7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLGNBQWM7Q0FDaEIsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGdCQUFnQixNQUFNO0VBQzFCLEVBQUUsZUFBZTtFQUNqQixjQUFjLE1BQU07Q0FDdEI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBcUI7R0FBc0I7Ozs7YUFDekQsd0JBQUMsUUFBRDtJQUFNLFVBQVU7SUFBYyxXQUFVO2NBQXhDLENBQ0Usd0JBQUMsU0FBRDtLQUNFLE1BQUs7S0FDTCxhQUFZO0tBQ1osT0FBTztLQUNQLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO0tBQ3pDLFdBQVU7SUFDWDs7OztjQUNELHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtlQUNYO0lBRU87Ozs7WUFDSjs7Ozs7V0FDSDs7Ozs7O0VBRUosVUFBVSxDQUFDLGFBQ1Ysd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUFvQztJQUNaO0lBQ3RCLHdCQUFDLFFBQUQsRUFBTSx5QkFBeUIsRUFBRSxRQUFRLE9BQU8sRUFBSTs7Ozs7R0FDakQ7Ozs7OztFQUdOLFlBQ0Msd0JBQUMsT0FBRDtHQUNFLFdBQVU7R0FDVix5QkFBeUIsRUFBRSxRQUFRLFVBQVU7RUFDOUM7Ozs7YUFFRCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLFNBQVMsS0FBSyxNQUNiLHdCQUFDLE9BQUQ7SUFFRSxXQUFVO2NBRlo7S0FJRSx3QkFBQyxPQUFEO01BQ0UsS0FBSyxFQUFFO01BQ1AsS0FBSTtNQUNKLFdBQVU7S0FDWDs7Ozs7S0FDRCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBdUMsRUFBRTtLQUFTOzs7OztLQUNoRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUNHLE9BQU8sRUFBRSxLQUFLLEVBQUUsZUFBZSxHQUFFLE1BQ2pDOzs7Ozs7S0FDSCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLFlBQVksRUFBRTtPQUNsQixXQUFVO2lCQUNYO01BRUs7Ozs7Z0JBRU4sd0JBQUMsVUFBRDtPQUNFLGVBQWUsVUFBVTtRQUFFLEdBQUc7UUFBRyxVQUFVO09BQUUsR0FBRyxDQUFDO09BQ2pELFdBQVU7aUJBQ1g7TUFFTzs7OztjQUNMOzs7Ozs7SUFDRjtNQTNCRSxFQUFFOzs7O1VBMkJKLENBQ047RUFDRTs7Ozs7RUFHTixTQUFTLFNBQVMsS0FDakIsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBZDtJQUF1RDtJQUMzQyxTQUFTO0lBQU87R0FDeEI7Ozs7OztDQUVIOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhvbWUuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tIFwiLi4vY29udGV4dC9DYXJ0Q29udGV4dFwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcclxuICBjb25zdCBbcHJvZHVjdHMsIHNldFByb2R1Y3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Vycm9ySHRtbCwgc2V0RXJyb3JIdG1sXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IHsgYWRkVG9DYXJ0IH0gPSB1c2VDYXJ0KCk7XHJcblxyXG4gIGNvbnN0IGZldGNoUHJvZHVjdHMgPSBhc3luYyAocXVlcnkgPSBcIlwiKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRFcnJvckh0bWwoXCJcIik7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF4aW9zLmdldChcclxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9wcm9kdWN0cz9zZWFyY2g9JHtxdWVyeX1gLFxyXG4gICAgICApO1xyXG4gICAgICBpZiAodHlwZW9mIHJlcy5kYXRhID09PSBcInN0cmluZ1wiICYmIHJlcy5kYXRhLmluY2x1ZGVzKFwiPGgxPlwiKSkge1xyXG4gICAgICAgIHNldEVycm9ySHRtbChyZXMuZGF0YSk7XHJcbiAgICAgICAgc2V0UHJvZHVjdHMoW10pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFByb2R1Y3RzKHJlcy5kYXRhKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIucmVzcG9uc2UgJiYgdHlwZW9mIGVyci5yZXNwb25zZS5kYXRhID09PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgc2V0RXJyb3JIdG1sKGVyci5yZXNwb25zZS5kYXRhKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFByb2R1Y3RzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWFyY2ggPSAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgZmV0Y2hQcm9kdWN0cyhzZWFyY2gpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZFwiPkRhbmggc8OhY2ggc+G6o24gcGjhuqltPC9oMT5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VhcmNofSBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlTDrG0ga2nhur9tLi4uXCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBUw6xtXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge3NlYXJjaCAmJiAhZXJyb3JIdG1sICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgS+G6v3QgcXXhuqMgdMOsbSBraeG6v20gY2hvOntcIiBcIn1cclxuICAgICAgICAgIDxzcGFuIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogc2VhcmNoIH19IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7ZXJyb3JIdG1sID8gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC0xMDAgcC00IHJvdW5kZWQgb3ZlcmZsb3ctYXV0b1wiXHJcbiAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGVycm9ySHRtbCB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGdhcC02XCI+XHJcbiAgICAgICAgICB7cHJvZHVjdHMubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e3AuaWR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgc2hhZG93LXNtIHAtNCBmbGV4IGZsZXgtY29sIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz17cC5pbWFnZVVybH1cclxuICAgICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC00OCBvYmplY3QtY292ZXIgbWItNCByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbWItMiB0cnVuY2F0ZVwiPntwLm5hbWV9PC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgZm9udC1ib2xkIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIHtOdW1iZXIocC5wcmljZSkudG9Mb2NhbGVTdHJpbmcoKX0gVk5EXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtYXV0byBmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICB0bz17YC9wcm9kdWN0LyR7cC5pZH1gfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgdGV4dC1jZW50ZXIgYmctZ3JheS0yMDAgcHktMiByb3VuZGVkIGhvdmVyOmJnLWdyYXktMzAwIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBYZW0gY2hpIHRp4bq/dFxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWRkVG9DYXJ0KHsgLi4ucCwgcXVhbnRpdHk6IDEgfSwgMSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHB5LTIgcm91bmRlZCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVGjDqm0gdsOgbyBnaeG7j1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7cHJvZHVjdHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgbXQtOCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICBIaeG7g24gdGjhu4sge3Byb2R1Y3RzLmxlbmd0aH0gc+G6o24gcGjhuqltXHJcbiAgICAgICAgPC9oMT5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19