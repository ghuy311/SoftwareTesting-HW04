import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ForgotPassword.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import axios from "/node_modules/.vite/deps/axios.js?v=4193fc5d";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=4193fc5d";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ForgotPassword.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$();
export default function ForgotPassword() {
	_s();
	const [email, setEmail] = useState("");
	const [step, setStep] = useState(1);
	const [resetToken, setResetToken] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [message, setMessage] = useState("");
	const navigate = useNavigate();
	const handleRequest = async (e) => {
		e.preventDefault();
		try {
			const res = await axios.post("http://localhost:3000/api/forgot-password", { email });
			setMessage(`Mã OTP của bạn là: ${res.data.resetToken}`);
			setStep(2);
		} catch (err) {
			alert("Lỗi: " + (err.response?.data?.error || err.message));
		}
	};
	const handleReset = async (e) => {
		e.preventDefault();
		const flawedStrongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*\s)[A-Za-z\d\s]{8,}$/;
		if (!flawedStrongPasswordRegex.test(newPassword)) {
			alert("Mật khẩu quá yếu! Phải dài tối thiểu 8 ký tự, gồm chữ hoa, chữ thường, số và KÝ TỰ ĐẶC BIỆT.");
			return;
		}
		try {
			await axios.post("http://localhost:3000/api/reset-password", {
				email,
				resetToken,
				newPassword
			});
			alert("Đổi mật khẩu thành công!");
			navigate("/login");
		} catch (err) {
			alert("Mã OTP không đúng hoặc có lỗi xảy ra.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "max-w-md mx-auto mt-10 bg-white p-8 border rounded shadow-sm",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold mb-6 text-center",
				children: "Quên Mật Khẩu"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			step === 1 && /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleRequest,
				className: "space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-gray-700 mb-2",
					children: "Nhập Email của bạn"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					type: "text",
					value: email,
					onChange: (e) => setEmail(e.target.value),
					className: "w-full border p-2 rounded",
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					className: "w-full bg-blue-600 text-white py-2 rounded",
					children: "Lấy mã OTP"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 9
			}, this),
			step === 2 && /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleReset,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-green-100 text-green-800 p-3 rounded text-sm mb-4",
						children: message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-gray-700 mb-2",
						children: "Mã OTP (4 số)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: resetToken,
						onChange: (e) => setResetToken(e.target.value),
						className: "w-full border p-2 rounded",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-gray-700 mb-2",
						children: "Mật khẩu mới"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "password",
						value: newPassword,
						onChange: (e) => setNewPassword(e.target.value),
						className: "w-full border p-2 rounded",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "w-full bg-green-600 text-white py-2 rounded",
						children: "Đặt lại mật khẩu"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setStep(1),
						className: "w-full bg-green-600 text-white py-2 rounded",
						children: "← Quay lại"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 5
	}, this);
}
_s(ForgotPassword, "eMYGnVyuqTpyz9aEg8nMoCvfcTQ=", false, function() {
	return [useNavigate];
});
_c = ForgotPassword;
var _c;
$RefreshReg$(_c, "ForgotPassword");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ForgotPassword.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ForgotPassword.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ForgotPassword.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/pages/ForgotPassword.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLFdBQVc7QUFDbEIsU0FBUyxhQUFhLFlBQVk7Ozs7QUFFbEMsZUFBZSxTQUFTLGlCQUFpQjs7Q0FDdkMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUM7Q0FDbEMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sZ0JBQWdCLE9BQU8sTUFBTTtFQUNqQyxFQUFFLGVBQWU7RUFDakIsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSyw2Q0FBNkMsRUFBRSxNQUFNLENBQUM7R0FDbkYsV0FBVyxzQkFBc0IsSUFBSSxLQUFLLFlBQVk7R0FDdEQsUUFBUSxDQUFDO0VBQ1gsU0FBUyxLQUFLO0dBQ1osTUFBTSxXQUFXLElBQUksVUFBVSxNQUFNLFNBQVMsSUFBSSxRQUFRO0VBQzVEO0NBQ0Y7Q0FFQSxNQUFNLGNBQWMsT0FBTyxNQUFNO0VBQy9CLEVBQUUsZUFBZTtFQUNqQixNQUFNLDRCQUE0QjtFQUNsQyxJQUFJLENBQUMsMEJBQTBCLEtBQUssV0FBVyxHQUFHO0dBQ2hELE1BQU0sOEZBQThGO0dBQ3BHO0VBQ0Y7RUFFQSxJQUFJO0dBQ0YsTUFBTSxNQUFNLEtBQUssNENBQTRDO0lBQUU7SUFBTztJQUFZO0dBQVksQ0FBQztHQUMvRixNQUFNLDBCQUEwQjtHQUNoQyxTQUFTLFFBQVE7RUFDbkIsU0FBUyxLQUFLO0dBQ1osTUFBTSx1Q0FBdUM7RUFDL0M7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXNDO0dBQWlCOzs7OztHQUVwRSxTQUFTLEtBQ1Isd0JBQUMsUUFBRDtJQUFNLFVBQVU7SUFBZSxXQUFVO2NBQXpDLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQTJCO0lBQXlCOzs7O2NBQ3JFLHdCQUFDLFNBQUQ7S0FDRSxNQUFLO0tBQ0wsT0FBTztLQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO0tBQ3hDLFdBQVU7S0FDVjtJQUNEOzs7O1lBQ0U7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVU7ZUFBNkM7SUFFckU7Ozs7WUFDSjs7Ozs7O0dBR1AsU0FBUyxLQUNSLHdCQUFDLFFBQUQ7SUFBTSxVQUFVO0lBQWEsV0FBVTtjQUF2QztLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaO0tBQ0U7Ozs7O0tBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUEyQjtLQUFvQjs7OztlQUNoRSx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztNQUM3QyxXQUFVO01BQ1Y7S0FDRDs7OzthQUNFOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBMkI7S0FBbUI7Ozs7ZUFDL0Qsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxPQUFPO01BQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7TUFDOUMsV0FBVTtNQUNWO0tBQ0Q7Ozs7YUFDRTs7Ozs7S0FHTCx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFdBQVU7Z0JBQThDO0tBRXRFOzs7OztLQUNSLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsZUFBZSxRQUFRLENBQUM7TUFBRyxXQUFVO2dCQUE4QztLQUVqRzs7Ozs7SUFDSjs7Ozs7O0VBRUw7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZvcmdvdFBhc3N3b3JkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGb3Jnb3RQYXNzd29yZCgpIHtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbcmVzZXRUb2tlbiwgc2V0UmVzZXRUb2tlbl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW25ld1Bhc3N3b3JkLCBzZXROZXdQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVxdWVzdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBheGlvcy5wb3N0KCdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2ZvcmdvdC1wYXNzd29yZCcsIHsgZW1haWwgfSk7XHJcbiAgICAgIHNldE1lc3NhZ2UoYE3DoyBPVFAgY+G7p2EgYuG6oW4gbMOgOiAke3Jlcy5kYXRhLnJlc2V0VG9rZW59YCk7XHJcbiAgICAgIHNldFN0ZXAoMik7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgYWxlcnQoXCJM4buXaTogXCIgKyAoZXJyLnJlc3BvbnNlPy5kYXRhPy5lcnJvciB8fCBlcnIubWVzc2FnZSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlc2V0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGZsYXdlZFN0cm9uZ1Bhc3N3b3JkUmVnZXggPSAvXig/PS4qW2Etel0pKD89LipbQS1aXSkoPz0uKlxcZCkoPz0uKlxccylbQS1aYS16XFxkXFxzXXs4LH0kLztcclxuICAgIGlmICghZmxhd2VkU3Ryb25nUGFzc3dvcmRSZWdleC50ZXN0KG5ld1Bhc3N3b3JkKSkge1xyXG4gICAgICBhbGVydCgnTeG6rXQga2jhuql1IHF1w6EgeeG6v3UhIFBo4bqjaSBkw6BpIHThu5FpIHRoaeG7g3UgOCBrw70gdOG7sSwgZ+G7k20gY2jhu68gaG9hLCBjaOG7ryB0aMaw4budbmcsIHPhu5EgdsOgIEvDnSBU4buwIMSQ4bq2QyBCSeG7hlQuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBheGlvcy5wb3N0KCdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Jlc2V0LXBhc3N3b3JkJywgeyBlbWFpbCwgcmVzZXRUb2tlbiwgbmV3UGFzc3dvcmQgfSk7XHJcbiAgICAgIGFsZXJ0KFwixJDhu5VpIG3huq10IGto4bqpdSB0aMOgbmggY8O0bmchXCIpO1xyXG4gICAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgYWxlcnQoXCJNw6MgT1RQIGtow7RuZyDEkcO6bmcgaG/hurdjIGPDsyBs4buXaSB44bqjeSByYS5cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgbXgtYXV0byBtdC0xMCBiZy13aGl0ZSBwLTggYm9yZGVyIHJvdW5kZWQgc2hhZG93LXNtXCI+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItNiB0ZXh0LWNlbnRlclwiPlF1w6puIE3huq10IEto4bqpdTwvaDI+XHJcblxyXG4gICAgICB7c3RlcCA9PT0gMSAmJiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVJlcXVlc3R9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtZ3JheS03MDAgbWItMlwiPk5o4bqtcCBFbWFpbCBj4bunYSBi4bqhbjwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBwLTIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcHktMiByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgIEzhuqV5IG3DoyBPVFBcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtzdGVwID09PSAyICYmIChcclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlUmVzZXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAgcC0zIHJvdW5kZWQgdGV4dC1zbSBtYi00XCI+XHJcbiAgICAgICAgICAgIHttZXNzYWdlfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1ncmF5LTcwMCBtYi0yXCI+TcOjIE9UUCAoNCBz4buRKTwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cmVzZXRUb2tlbn1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlc2V0VG9rZW4oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LWdyYXktNzAwIG1iLTJcIj5N4bqtdCBraOG6qXUgbeG7m2k8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtuZXdQYXNzd29yZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1Bhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB5LTIgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICDEkOG6t3QgbOG6oWkgbeG6rXQga2jhuql1XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoMSl9IGNsYXNzTmFtZT1cInctZnVsbCBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweS0yIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAg4oaQIFF1YXkgbOG6oWlcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19