import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport13_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import { BrowserRouter as Router, Routes, Route, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=4193fc5d";
import { useCart } from "/src/context/CartContext.jsx";
import Home from "/src/pages/Home.jsx";
import Login from "/src/pages/Login.jsx";
import Register from "/src/pages/Register.jsx";
import ProductDetail from "/src/pages/ProductDetail.jsx";
import Cart from "/src/pages/Cart.jsx";
import Checkout from "/src/pages/Checkout.jsx";
import ForgotPassword from "/src/pages/ForgotPassword.jsx";
import Profile from "/src/pages/Profile.jsx";
import { AuthProvider, useAuth } from "/src/context/AuthContext.jsx";
import { CartProvider } from "/src/context/CartContext.jsx";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/App.jsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$();
function Header() {
	_s();
	const { user, logout } = useAuth();
	const { cart } = useCart ? useCart() : { cart: [] };
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "bg-blue-600 text-white p-4 flex justify-between items-center",
		children: [/* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			className: "text-2xl font-bold",
			children: "EShop"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("nav", {
			className: "flex gap-4 items-center",
			children: [/* @__PURE__ */ _jsxDEV(Link, {
				to: "/cart",
				className: "hover:underline",
				children: "Giỏ hàng"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this), user ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-4 items-center",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/profile",
					className: "hover:underline text-yellow-300",
					children: /* @__PURE__ */ _jsxDEV("span", { dangerouslySetInnerHTML: { __html: `Chào, ${user.name}` } }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: logout,
					className: "bg-red-500 px-3 py-1 rounded",
					children: "Thoát"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Link, {
				to: "/login",
				className: "hover:underline",
				children: "Đăng nhập"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV(Link, {
				to: "/register",
				className: "hover:underline",
				children: "Đăng ký"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_s(Header, "klbUi0HuOX8DodRCpZxHhyo/QSA=", false, function() {
	return [useAuth, useCart];
});
_c = Header;
function App() {
	return /* @__PURE__ */ _jsxDEV(Router, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(CartProvider, { children: /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-gray-50 flex flex-col",
		children: [
			/* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-grow p-4 container mx-auto max-w-5xl",
				children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/",
						element: /* @__PURE__ */ _jsxDEV(Home, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 42
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/login",
						element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 47
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/register",
						element: /* @__PURE__ */ _jsxDEV(Register, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 50
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/forgot-password",
						element: /* @__PURE__ */ _jsxDEV(ForgotPassword, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 57
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/profile",
						element: /* @__PURE__ */ _jsxDEV(Profile, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 49
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/product/:id",
						element: /* @__PURE__ */ _jsxDEV(ProductDetail, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 53
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/cart",
						element: /* @__PURE__ */ _jsxDEV(Cart, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 46
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/checkout",
						element: /* @__PURE__ */ _jsxDEV(Checkout, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 50
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 17
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "bg-gray-800 text-white text-center p-4 mt-8",
				children: "© 2026 EShop SUT. Dành cho mục đích kiểm thử."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 11
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
}
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Header");
$RefreshReg$(_c2, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsaUJBQWlCLFFBQVEsUUFBUSxPQUFPLFlBQVk7QUFDN0QsU0FBUyxlQUFlO0FBQ3hCLE9BQU8sVUFBVTtBQUNqQixPQUFPLFdBQVc7QUFDbEIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8sVUFBVTtBQUNqQixPQUFPLGNBQWM7QUFDckIsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyxhQUFhO0FBQ3BCLFNBQVMsY0FBYyxlQUFlO0FBQ3RDLFNBQVMsb0JBQW9COzs7O0FBRTdCLFNBQVMsU0FBUzs7Q0FDaEIsTUFBTSxFQUFFLE1BQU0sV0FBVyxRQUFRO0NBQ2pDLE1BQU0sRUFBRSxTQUFTLFVBQVUsUUFBUSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUU7Q0FFbEQsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUFsQixDQUNFLHdCQUFDLE1BQUQ7R0FBTSxJQUFHO0dBQUksV0FBVTthQUFxQjtFQUFXOzs7O1lBQ3ZELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFRLFdBQVU7Y0FBa0I7R0FBYzs7OzthQUMxRCxPQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFXLFdBQVU7ZUFDNUIsd0JBQUMsUUFBRCxFQUFNLHlCQUF5QixFQUFFLFFBQVEsU0FBUyxLQUFLLE9BQU8sRUFBSTs7Ozs7SUFDOUQ7Ozs7Y0FDTix3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFRLFdBQVU7ZUFBK0I7SUFBYTs7OztZQUM1RTs7Ozs7Y0FFTCxnREFDRSx3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFTLFdBQVU7Y0FBa0I7R0FBZTs7OzthQUM3RCx3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFZLFdBQVU7Y0FBa0I7R0FBYTs7OztXQUM5RDs7OztXQUVEOzs7OztVQUNDOzs7Ozs7QUFFWjs7Ozs7QUFFQSxTQUFTLE1BQU07Q0FDYixPQUNFLHdCQUFDLFFBQUQsWUFDRSx3QkFBQyxjQUFELFlBQ0Usd0JBQUMsY0FBRCxZQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxRQUFELENBQVM7Ozs7O0dBQ1Qsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxRQUFEO0tBQ0Usd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBSSxTQUFTLHdCQUFDLE1BQUQsQ0FBTzs7Ozs7S0FBSTs7Ozs7S0FDcEMsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBUyxTQUFTLHdCQUFDLE9BQUQsQ0FBUTs7Ozs7S0FBSTs7Ozs7S0FDMUMsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBWSxTQUFTLHdCQUFDLFVBQUQsQ0FBVzs7Ozs7S0FBSTs7Ozs7S0FDaEQsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBbUIsU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7S0FBSTs7Ozs7S0FDN0Qsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBVyxTQUFTLHdCQUFDLFNBQUQsQ0FBVTs7Ozs7S0FBSTs7Ozs7S0FDOUMsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBZSxTQUFTLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0tBQUk7Ozs7O0tBQ3hELHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQVEsU0FBUyx3QkFBQyxNQUFELENBQU87Ozs7O0tBQUk7Ozs7O0tBQ3hDLHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQVksU0FBUyx3QkFBQyxVQUFELENBQVc7Ozs7O0tBQUk7Ozs7O0lBQzFDOzs7OztHQUNKOzs7OztHQUNOLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQThDO0dBRXhEOzs7OztFQUNMOzs7OztVQUNPOzs7O1VBQ0Y7Ozs7VUFDUjs7Ozs7QUFFWjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlcywgUm91dGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQ2FydCB9IGZyb20gJy4vY29udGV4dC9DYXJ0Q29udGV4dCc7XHJcbmltcG9ydCBIb21lIGZyb20gJy4vcGFnZXMvSG9tZSc7XHJcbmltcG9ydCBMb2dpbiBmcm9tICcuL3BhZ2VzL0xvZ2luJztcclxuaW1wb3J0IFJlZ2lzdGVyIGZyb20gJy4vcGFnZXMvUmVnaXN0ZXInO1xyXG5pbXBvcnQgUHJvZHVjdERldGFpbCBmcm9tICcuL3BhZ2VzL1Byb2R1Y3REZXRhaWwnO1xyXG5pbXBvcnQgQ2FydCBmcm9tICcuL3BhZ2VzL0NhcnQnO1xyXG5pbXBvcnQgQ2hlY2tvdXQgZnJvbSAnLi9wYWdlcy9DaGVja291dCc7XHJcbmltcG9ydCBGb3Jnb3RQYXNzd29yZCBmcm9tICcuL3BhZ2VzL0ZvcmdvdFBhc3N3b3JkJztcclxuaW1wb3J0IFByb2ZpbGUgZnJvbSAnLi9wYWdlcy9Qcm9maWxlJztcclxuaW1wb3J0IHsgQXV0aFByb3ZpZGVyLCB1c2VBdXRoIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuaW1wb3J0IHsgQ2FydFByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0L0NhcnRDb250ZXh0JztcclxuXHJcbmZ1bmN0aW9uIEhlYWRlcigpIHtcclxuICBjb25zdCB7IHVzZXIsIGxvZ291dCB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IHsgY2FydCB9ID0gdXNlQ2FydCA/IHVzZUNhcnQoKSA6IHsgY2FydDogW10gfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBwLTQgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZFwiPkVTaG9wPC9MaW5rPlxyXG4gICAgICA8bmF2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgPExpbmsgdG89XCIvY2FydFwiIGNsYXNzTmFtZT1cImhvdmVyOnVuZGVybGluZVwiPkdp4buPIGjDoG5nPC9MaW5rPlxyXG4gICAgICAgIHt1c2VyID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8TGluayB0bz1cIi9wcm9maWxlXCIgY2xhc3NOYW1lPVwiaG92ZXI6dW5kZXJsaW5lIHRleHQteWVsbG93LTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogYENow6BvLCAke3VzZXIubmFtZX1gIH19IC8+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtsb2dvdXR9IGNsYXNzTmFtZT1cImJnLXJlZC01MDAgcHgtMyBweS0xIHJvdW5kZWRcIj5UaG/DoXQ8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8TGluayB0bz1cIi9sb2dpblwiIGNsYXNzTmFtZT1cImhvdmVyOnVuZGVybGluZVwiPsSQxINuZyBuaOG6rXA8L0xpbms+XHJcbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCIgY2xhc3NOYW1lPVwiaG92ZXI6dW5kZXJsaW5lXCI+xJDEg25nIGvDvTwvTGluaz5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvbmF2PlxyXG4gICAgPC9oZWFkZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Um91dGVyPlxyXG4gICAgICA8QXV0aFByb3ZpZGVyPlxyXG4gICAgICAgIDxDYXJ0UHJvdmlkZXI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmF5LTUwIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgPEhlYWRlciAvPlxyXG4gICAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC00IGNvbnRhaW5lciBteC1hdXRvIG1heC13LTV4bFwiPlxyXG4gICAgICAgICAgICAgIDxSb3V0ZXM+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8SG9tZSAvPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PExvZ2luIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVnaXN0ZXJcIiBlbGVtZW50PXs8UmVnaXN0ZXIgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9mb3Jnb3QtcGFzc3dvcmRcIiBlbGVtZW50PXs8Rm9yZ290UGFzc3dvcmQgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9wcm9maWxlXCIgZWxlbWVudD17PFByb2ZpbGUgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9wcm9kdWN0LzppZFwiIGVsZW1lbnQ9ezxQcm9kdWN0RGV0YWlsIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY2FydFwiIGVsZW1lbnQ9ezxDYXJ0IC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY2hlY2tvdXRcIiBlbGVtZW50PXs8Q2hlY2tvdXQgLz59IC8+XHJcbiAgICAgICAgICAgICAgPC9Sb3V0ZXM+XHJcbiAgICAgICAgICAgIDwvbWFpbj5cclxuICAgICAgICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJiZy1ncmF5LTgwMCB0ZXh0LXdoaXRlIHRleHQtY2VudGVyIHAtNCBtdC04XCI+XHJcbiAgICAgICAgICAgICAgJmNvcHk7IDIwMjYgRVNob3AgU1VULiBEw6BuaCBjaG8gbeG7pWMgxJHDrWNoIGtp4buDbSB0aOG7rS5cclxuICAgICAgICAgICAgPC9mb290ZXI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0NhcnRQcm92aWRlcj5cclxuICAgICAgPC9BdXRoUHJvdmlkZXI+XHJcbiAgICA8L1JvdXRlcj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdfQ==