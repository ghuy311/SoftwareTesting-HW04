import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useState = __vite__cjsImport0_react["useState"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4193fc5d";
import axios from "/node_modules/.vite/deps/axios.js?v=4193fc5d";
var _jsxFileName = "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/AuthContext.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4193fc5d";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(null);
_c = AuthContext;
export const AuthProvider = ({ children }) => {
	_s();
	const [user, setUser] = useState(null);
	const [token, setToken] = useState(localStorage.getItem("token"));
	useEffect(() => {
		if (token) {
			axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
			axios.get("http://localhost:3000/api/users/me").then((res) => {
				setUser(res.data);
			}).catch(() => {
				logout();
			});
		} else {
			delete axios.defaults.headers.common["Authorization"];
		}
	}, [token]);
	const login = async (email, password) => {
		const res = await axios.post("http://localhost:3000/api/login", {
			email,
			password
		});
		setToken(res.data.token);
		localStorage.setItem("token", res.data.token);
		setUser(res.data.user);
		return res.data;
	};
	const logout = () => {
		setToken(null);
		setUser(null);
		localStorage.removeItem("token");
	};
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			user,
			token,
			login,
			logout
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
};
_s(AuthProvider, "xRi9FJQ+swd/M9mL2eP2NEF6hxc=");
_c2 = AuthProvider;
export const useAuth = () => {
	_s2();
	return useContext(AuthContext);
};
_s2(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/HUYNH BINH/Desktop/SUT/eshop-sut/frontend-web/src/context/AuthContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsVUFBVSxZQUFZLGlCQUFpQjtBQUN0RSxPQUFPLFdBQVc7Ozs7QUFFbEIsTUFBTSxjQUFjLGNBQWMsSUFBSTs7QUFFdEMsT0FBTyxNQUFNLGdCQUFnQixFQUFFLGVBQWU7O0NBQzVDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0NBQ3JDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxhQUFhLFFBQVEsT0FBTyxDQUFDO0NBRWhFLGdCQUFnQjtFQUNkLElBQUksT0FBTztHQUNULE1BQU0sU0FBUyxRQUFRLE9BQU8sbUJBQW1CLFVBQVU7R0FDM0QsTUFDRyxJQUFJLG9DQUFvQyxFQUN4QyxNQUFNLFFBQVE7SUFDYixRQUFRLElBQUksSUFBSTtHQUNsQixDQUFDLEVBQ0EsWUFBWTtJQUNYLE9BQU87R0FDVCxDQUFDO0VBQ0wsT0FBTztHQUNMLE9BQU8sTUFBTSxTQUFTLFFBQVEsT0FBTztFQUN2QztDQUNGLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixNQUFNLFFBQVEsT0FBTyxPQUFPLGFBQWE7RUFDdkMsTUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLLG1DQUFtQztHQUM5RDtHQUNBO0VBQ0YsQ0FBQztFQUNELFNBQVMsSUFBSSxLQUFLLEtBQUs7RUFDdkIsYUFBYSxRQUFRLFNBQVMsSUFBSSxLQUFLLEtBQUs7RUFDNUMsUUFBUSxJQUFJLEtBQUssSUFBSTtFQUNyQixPQUFPLElBQUk7Q0FDYjtDQUVBLE1BQU0sZUFBZTtFQUNuQixTQUFTLElBQUk7RUFDYixRQUFRLElBQUk7RUFDWixhQUFhLFdBQVcsT0FBTztDQUNqQztDQUVBLE9BQ0Usd0JBQUMsWUFBWSxVQUFiO0VBQXNCLE9BQU87R0FBRTtHQUFNO0dBQU87R0FBTztFQUFPO0VBQ3ZEO0NBQ21COzs7OztBQUUxQjs7O0FBRUEsT0FBTyxNQUFNLGdCQUFnQjs7bUJBQVcsV0FBVyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IGNyZWF0ZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5cclxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0KG51bGwpO1xyXG5cclxuZXhwb3J0IGNvbnN0IEF1dGhQcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdG9rZW4sIHNldFRva2VuXSA9IHVzZVN0YXRlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidG9rZW5cIikpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHRva2VuKSB7XHJcbiAgICAgIGF4aW9zLmRlZmF1bHRzLmhlYWRlcnMuY29tbW9uW1wiQXV0aG9yaXphdGlvblwiXSA9IGBCZWFyZXIgJHt0b2tlbn1gO1xyXG4gICAgICBheGlvc1xyXG4gICAgICAgIC5nZXQoXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3VzZXJzL21lXCIpXHJcbiAgICAgICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICAgICAgc2V0VXNlcihyZXMuZGF0YSk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgICAgbG9nb3V0KCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkZWxldGUgYXhpb3MuZGVmYXVsdHMuaGVhZGVycy5jb21tb25bXCJBdXRob3JpemF0aW9uXCJdO1xyXG4gICAgfVxyXG4gIH0sIFt0b2tlbl0pO1xyXG5cclxuICBjb25zdCBsb2dpbiA9IGFzeW5jIChlbWFpbCwgcGFzc3dvcmQpID0+IHtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF4aW9zLnBvc3QoXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2xvZ2luXCIsIHtcclxuICAgICAgZW1haWwsXHJcbiAgICAgIHBhc3N3b3JkLFxyXG4gICAgfSk7XHJcbiAgICBzZXRUb2tlbihyZXMuZGF0YS50b2tlbik7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInRva2VuXCIsIHJlcy5kYXRhLnRva2VuKTtcclxuICAgIHNldFVzZXIocmVzLmRhdGEudXNlcik7XHJcbiAgICByZXR1cm4gcmVzLmRhdGE7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgc2V0VG9rZW4obnVsbCk7XHJcbiAgICBzZXRVc2VyKG51bGwpO1xyXG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJ0b2tlblwiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IHVzZXIsIHRva2VuLCBsb2dpbiwgbG9nb3V0IH19PlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L0F1dGhDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgdXNlQXV0aCA9ICgpID0+IHVzZUNvbnRleHQoQXV0aENvbnRleHQpO1xyXG4iXX0=